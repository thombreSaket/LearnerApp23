package hhird.harsh123.com.learnerapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class tutorials extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tutorials);
    }
}
