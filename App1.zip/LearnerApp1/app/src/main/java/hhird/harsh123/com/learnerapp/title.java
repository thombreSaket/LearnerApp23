package hhird.harsh123.com.learnerapp;

public class title {

    String qtitle;

    public title(String qtitle) {
        this.qtitle = qtitle;


    }



    public String getQtitle() {
        return qtitle;
    }


}

